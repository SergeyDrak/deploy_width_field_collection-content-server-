Date Repeat Field

The functionality to integrate the Date Repeat API into date fields is being moved into this module,
which can then be enabled or disabled, depending on whether repeating date fields are needed.